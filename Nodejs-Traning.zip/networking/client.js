const net = require('net')
const readline = require('readline')
const clientSocket =  new net.Socket();

const readConsole = readline.createInterface({
    input: process.stdin,
    ouput: process.stdout
})
clientSocket.connect(9001, 'localhost', () => {
    console.log("Connected to server");
    clientSocket.setEncoding('utf8');
    clientSocket.on("data", (data) => {
        console.log(`${data}`)
        //clientSocket.write(data);
        readConsole.setPrompt("Enter message text to server>>");
        readConsole.prompt();
    });

    readConsole.on("line", (data) => {
        clientSocket.write(data)
        readConsole.prompt();
    })
});