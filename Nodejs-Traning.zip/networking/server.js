const net = require('net')
const server = net.createServer();

const allSockets = []
var counter = 0;
server.on("connection", (socket) => {
    var clientId = ++counter;
    allSockets.push(socket)
    console.log("Client Connected")
    socket.setEncoding('utf8');
    socket.write("Hello");
    socket.on('data', (data) =>{
        console.log(`Client says: ${data}`)
        allSockets.forEach(socketItem => {
            if(socketItem != socket)
            socketItem.write(`Client ${clientId}: ${data}`)
        })
    });
    
    socket.on('error', () => {
        console.log('Client disconnected')
    })
})

server.listen(9001, () => {
    console.log("Server started at port 9001")
})