const http = require('http')
const pid = process.pid

var server = http.createServer();

server.on("request", (res, resp) => {
    for(let i=0; i<ie7; i++) {
        resp.end(`Handled by process ${pid}`);
    }
})

server.listen(8080, () => {
    console.log(`started process ${pid}`)
})