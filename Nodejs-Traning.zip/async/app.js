console.log('Starting of the app...')

function process(callback) {
    console.log("In Process")
    callback();
    console.log("In Process Completed")
}

process(function() {
    console.log("In Process callback")
})

setTimeout(function(){
    console.log('in timeout for 3 secs')
}, 3000)

setTimeout(function(){
    console.log('in timeout for 0 secs')
}, 0)

console.log('Ending app...')