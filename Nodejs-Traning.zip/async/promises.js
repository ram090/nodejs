function task(arg) {
    console.log("Starting task")
    return new Promise(function(resolve, reject){
        console.log("In Promise")
        if(arg >50) {
            setTimeout(() => {
                var result = arg * 2
                resolve(result)
            }, 3000)
        } else {
            setTimeout(() => {
                var result = arg * 8
                reject(result)
            }, 2000)
        }
    })
    
}

// //var handle = task(20);
// Promise.all([Promise.resolve("a"), Promise.resolve("b"), task(20)])
//     .then((result) => {
//         console.log("Resolved ", result)
//     }, (result) => {
//         console.log("Rejected ",result)
//     })
// console.log("Finishing")

const invokeSomefn = async () => {
    try {
        var result = await task(150)
        console.log("result", result)
    } catch( err ) {
        console.log("err",err)
    }
}

invokeSomefn();