function sum(x,y) {
    console.log("In sum")
}

sum(2,3)
sum()

// Function expression
var add =  function(a,b) {
    return a + b
}

var add = (a, b) => a + b
console.log(add(4,5))



var obj = {
    id: 100,
    print: function() {
        console.log("Id ", this.id)
        setTimeout(() => {
            console.log("Id After 2 sec", this.id)
        }, 2000)
    }
}

obj.print();
