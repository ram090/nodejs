console.log('...in app.js');

const module1 = require('module1')
//const lib = require('my-lib')
console.log(module1)

const module2 = require('module1')
//const lib = require('my-lib')
console.log(module2)

const os = require('os')

const functions = require('./functions')

console.log("Functions for add 1,2: ", functions(1,2))