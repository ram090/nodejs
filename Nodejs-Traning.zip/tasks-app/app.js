console.log('In the Tasks Application')

const yargs =  require('yargs')
const fs = require('fs')
const tasks = require('./tasks')

yargs.command("add", "To add a new task", () => {
    return yargs.options({
        task: {
            describe: "The task name",
            demand: true,
            alias: "t"
        },
        desc: {
            describe: "The task description",
            demand: true,
            alias: "t"
        }
    })
}).command("list", "To List all tasks").help();

console.log(yargs.argv);

tasks.taskEmitter.on('data',  (data) => {
    console.log("In the data event");
    data.forEach(item => {
        console.log(`Task Name: ${item.taskName}`);
        console.log(`Description: ${item.desc}`)
    })
})

const command = process.argv[2]


if(command === 'add'){
    var taskName = yargs.argv.task
    var desc = yargs.argv.desc
    var task = {
        task: taskName,
        desc: desc
    }
    // console.log("Add mode: ",task)

    // fs.writeFileSync("Tasks.json", JSON.stringify(task))
    tasks.writeTask(taskName, desc).then((task) => console.log(task), (err) => console.log(err))
} else if(command === 'list' ){
    console.log('List Mode')
    tasks.readTasks().then((data) => {
        data.forEach(item => {
            console.log(item)
        });
    }, (err) => { console.log(err)})
} else {
    console.log('unknown Command')
}