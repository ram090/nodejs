var fs = require('fs')
var EventEmitter =  require('events')

class TaskEmitter extends EventEmitter { 

}

var taskEmitter = new TaskEmitter();

function writeTask(taskName, desc) {
    var task = {
        taskName,
        desc
    }
    var tasks = []
    
    return new Promise(async (resolve, reject) => {

        try {
            var data = await readTasks();
            tasks = data
        } catch(err) {
            tasks = []
        }

        tasks.push(task)
        fs.writeFile('Tasks.json', JSON.stringify(tasks), err => {
            if(err){
                console.log('Error:', err)
                reject(err);
               
            }
            else{
                resolve(task);
                
            }
        })
        // readTasks().then((data) => { 
        //     tasks = data
           
        // }).catch( (err) => {
        //     console.log("Error reading file", err)
        //     tasks = []
        // }).then(() => {
        //     console.log("in Final then....")
        //     tasks.push(task)
        //     fs.writeFile('Tasks.json', JSON.stringify(tasks), err => {
        //         if(err){
        //             console.log('Error:', err)
        //             reject(err);
        //         }
        //         else{
        //             resolve(task);
        //         }
        //     })
        // })
    })
    
}

function readTasks() {

    return new Promise((resolve, reject) => {
        fs.readFile("Tasks.json", (err, data) => {
            if(err){
                reject(err);
                taskEmitter.emit('error', err)
            } else {
                console.log(JSON.parse(data))
                resolve(JSON.parse(data))
                taskEmitter.emit('data', JSON.parse(data))
            }
        });
    })
    
}

module.exports = { writeTask, readTasks, taskEmitter }