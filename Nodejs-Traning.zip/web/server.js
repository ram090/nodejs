const http = require('http')

var server = http.createServer();

server.on("request", (req, resp) => {
    console.log("Handling the request...");
    resp.writeHead(200, { 'Content-Type': 'text/html' });
    resp.write("<h2>Hello Http Web App</h2>");
    resp.end();
})

server.listen(8080, () => {
    console.log('Http server started')
})