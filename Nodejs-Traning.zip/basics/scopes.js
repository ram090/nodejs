var x = 10
var y;

console.log('x: ', x)
console.log('y: ', y)

function fn() {
    var x = 10
    console.log('x in fn', x)
    if( x < 20) {
        let message = "Hello"
        console.log('Message', message)
    }
}
fn();