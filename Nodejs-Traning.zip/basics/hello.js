console.log("Hello")

var x = 10

console.log('x=',x);
console.log('global x=', global.x)

y = 30
console.log('y=',y)
console.log('global y=', global.y)